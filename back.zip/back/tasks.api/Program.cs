using System.Globalization;
using tasks.service;


var builder = WebApplication.CreateBuilder(args);
// Movendo toda Logina de Program para o Metodo Extensor
builder.StartApp("Task API");
public partial class Program { }