﻿using Microsoft.AspNetCore.Identity;

namespace tasks.shared.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Outros Atributos
    }

}
