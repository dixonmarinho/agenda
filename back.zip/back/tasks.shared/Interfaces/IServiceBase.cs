﻿namespace tasks.shared.Interfaces
{
    public interface IServiceBase<T, X> where T : class where X : class
    {
        Task<Result<bool>> CreateAsync(T model);
        Task<Result<bool>> UpdateAsync(T model);
        Task<Result<bool>> DeleteAsync(T model);
        Task<Result<T>> GetAsync(X id);
        Task<Result<IEnumerable<T>>> GetAllAsync();
    }
}
