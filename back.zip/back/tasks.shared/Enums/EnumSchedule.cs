﻿namespace tasks.shared.Enums
{
    public enum EnumtasksStatus
    {
        Pendente = 0,
        Concluido = 1
    }
}
