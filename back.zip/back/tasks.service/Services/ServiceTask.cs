﻿using AutoMapper;
using tasks.data.Data;
using tasks.shared;
using tasks.shared.Interfaces;
using tasks.shared.Models;

namespace tasks.service.Services
{
    public class ServiceTask : IServiceBase<TaskModelDTO, TaskModel>
    {
        private readonly IUnitOfWork<AppDataContext> db;
        private readonly IMapper map;

        public ServiceTask(IUnitOfWork<AppDataContext> db, IMapper map)
        {
            this.db = db;
            this.map = map;
        }

        public async Task<Result<bool>> CreateAsync(TaskModelDTO sender)
        {
            var repository = db.GetRepository<TaskModel>();
            var response = await repository.AddAsync(map.Map<TaskModel>(sender));
            return Result<bool>.Success();
        }

        public Task<Result<bool>> DeleteAsync(TaskModelDTO sender)
        {
            throw new NotImplementedException();
        }

        public Task<Result<TaskModelDTO>> GetAsync(TaskModel id)
        {
            throw new NotImplementedException();
        }

        public async Task<Result<IEnumerable<TaskModelDTO>>> GetAllAsync()
        {
            var response = await db.GetRepository<TaskModel>().GetAllAsync();
            return Result<IEnumerable<TaskModelDTO>>.Success(map.Map<IEnumerable<TaskModelDTO>>(response));
        }

        public async Task<Result<bool>> UpdateAsync(TaskModelDTO sender)
        {
            var repository = db.GetRepository<TaskModel>();
            var responseData = await repository.GetByIdAsync(sender.Id);
            map.Map(sender, responseData);
            var response = await repository.UpdateAsync(responseData);
            return Result<bool>.Success();
        }

    }
}
