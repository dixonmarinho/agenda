﻿using tasks.shared.Enums;
using tasks.shared.Interfaces;
using tasks.shared.Models;
using tasks.test.Base;
using Xunit.Abstractions;

namespace tasks.test
{
    public class Task_Service_Test : Base_Service_Test<Program>
    {
        private readonly IServiceBase<TaskModelDTO, TaskModel> service;

        public Task_Service_Test(ITestOutputHelper outputWriter) : base(outputWriter)
        {
            service = GetService<IServiceBase<TaskModelDTO, TaskModel>>();
        }


        // Cria um Texto Randomico
        private string GetRandonText()
        {
            return Guid.NewGuid().ToString().Substring(0, 10);
        }


        /// <summary>
        /// Cria varias tarefas aleatórias
        /// </summary>
        /// <param name="qde"></param>
        [Theory]
        [InlineData(10)]
        public async Task CreateAsyncTest(int qde)
        {
            EnumtasksStatus status;
            for (int i = 0; i < qde; i++)
            {
                if (i % 2 == 0)
                    status = EnumtasksStatus.Pendente;
                else
                    status = EnumtasksStatus.Concluido;

                var task = new TaskModelDTO
                {
                    Titulo = "TAREFA - " + GetRandonText(),
                    Descricao = "TAREFA AGENDADA - " + GetRandonText(),
                    Data = DateTime.Now.AddMinutes(30),
                    Status = status
                };
                var response = await service.CreateAsync(task);
                Assert.True(response.success == true, response.xmessage);
            }
        }


        [Fact]
        public async Task UpdateAsync()
        {
            // Pega um Registro
            var response = await service.GetAllAsync();
            var respondeRecord = response.data.FirstOrDefault();
            if (respondeRecord != null)
            {
                // Atualiza o Registro
                respondeRecord.Titulo = "TAREFA - " + GetRandonText();
                respondeRecord.Descricao = "TAREFA AGENDADA - " + GetRandonText();
                respondeRecord.Data = DateTime.Now.AddMinutes(30);
                respondeRecord.Status = EnumtasksStatus.Concluido;

                // Atualiza o Registro
                var responseUpdate = await service.UpdateAsync(respondeRecord);
                Assert.True(responseUpdate.success == true, responseUpdate.xmessage);
            }
        }

    }
}
